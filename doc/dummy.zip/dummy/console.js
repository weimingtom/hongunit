/**
 * @author weimingtom
 * @see http://www40.atwiki.jp/spellbound/pages/1890.html
 */

var console = window.console;
/**
 *  
 * @param {String} str
 */
console.log = function(str) {};
/**
 * 
 * @param {String} str
 */
console.info = function(str) {};
/**
 * 
 * @param {String} str
 */
console.warn = function(str) {};
/**
 * 
 * @param {String} str
 */
console.error = function(str) {};
/**
 * ダンプして階層的に表示
 */
console.dir = function() {};
/**
 * 呼び出し元メソッドの表示 
 */
console.trace = function() {};
/**
 * 
 * @param {String} str
 */
console.time = function(str) {};
/**
 * 
 * @param {String} str
 */
console.timeEnd = function(str){};

